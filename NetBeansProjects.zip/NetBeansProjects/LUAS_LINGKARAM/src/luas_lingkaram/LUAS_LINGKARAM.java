/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package luas_lingkaram;

/**
 *
 * @author ASUS
 */
public class LUAS_LINGKARAM {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //RUMUS
        double phi=3.14;
        double r=10;
        
        double L=phi*(r*r);
        //HASIL
        System.out.println("menghitung luas lingkaran");
        System.out.println("Dik:");
        System.out.println("nilai jari-jari (r)="+r);
        System.out.println("nilai phi yang digunakan="+phi);
        System.out.println("maka:");
        System.out.println("Luas lingkaran="+L);
        
    }
    
    
}
